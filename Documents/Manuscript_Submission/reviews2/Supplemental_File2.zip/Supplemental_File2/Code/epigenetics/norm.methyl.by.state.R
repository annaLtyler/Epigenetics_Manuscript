#This function takes in results from methylation.vs.state
#and returns the normalized methylation 

norm.methyl.by.state <- function(results.obj, state = 7, strain = "B6", gene.name, gene.info){


    
}