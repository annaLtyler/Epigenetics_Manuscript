#find the slope of a line given x and y coordinates

slope <- function(x0, x1, y0, y1){
    return((y1-y0)/(x1-x0))
    }
